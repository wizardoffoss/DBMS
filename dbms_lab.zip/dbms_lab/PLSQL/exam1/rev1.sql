set serveroutput on
declare
	a int;
begin
	a:=&a;
	revv(a);
end;
/