set serveroutput on
declare
	counter int;
begin
    cde();
end;
/