set server output on
declare
a int;
b int;
begin
a:=&a;
dc(a)
/